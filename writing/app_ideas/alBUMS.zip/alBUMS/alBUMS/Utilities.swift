//
//  Utilities.swift
//  alBUMS
//
//  Created by Zachary Hansen Terry on 7/18/24.
//

import Foundation

class Utilities {
    static func afterFirstHyphen(string: String) -> String {
        if let hyphenIndex = string.firstIndex(of: "-") {
            let afterHyphenIndex = string.index(after: hyphenIndex)
            let finIndex = string.index(after: afterHyphenIndex)
            let substring = string[finIndex...]
            return String(substring)
        } else {
            return string
        }
    }
        
    static func dropAfterHyphen(string: String) -> String {
        if let hyphenIndex = string.firstIndex(of: "-") {
            let substring = string[..<hyphenIndex]
            return String(substring)
        } else {
            return string
        }
    }
}
