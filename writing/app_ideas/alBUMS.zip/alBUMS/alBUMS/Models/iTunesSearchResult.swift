//
//  iTunesSearchResult.swift
//  alBUMS
//
//  Created by Zachary Hansen Terry on 7/19/24.
//

import Foundation

struct iTunesSearchResult: Decodable {
    let results: [iTunesAlbum]
}
