//
//  iTunesAlbum.swift
//  alBUMS
//
//  Created by Zachary Hansen Terry on 7/19/24.
//

import Foundation

struct iTunesAlbum: Identifiable, Codable {
    var id = UUID()
    var artistName: String
    var collectionName: String
    var artworkUrl100: String?
    var artworkUrl800: String?
    var localImage: Data?

    private enum CodingKeys: String, CodingKey {
        case artistName
        case collectionName
        case artworkUrl100
    }
    
    mutating func updateArtworkurl800() {
        if let artworkUrl100 = artworkUrl100 {
            artworkUrl800 = artworkUrl100.replacingOccurrences(of: "100x100bb", with: "800x800bb")
        }
    }
    
}
