//
//  DiscogSearchResults.swift
//  alBUMS
//
//  Created by Zachary Hansen Terry on 7/17/24.
//

import Foundation

struct DiscogSearchResult: Decodable {
    let results: [DiscogAlbum]
}
