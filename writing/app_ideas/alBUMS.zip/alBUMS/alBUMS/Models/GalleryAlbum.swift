//
//  GalleryAlbum.swift
//  alBUMS
//
//  Created by Zachary Hansen Terry on 7/19/24.
//

import Foundation

struct GalleryAlbum: Identifiable, Codable {
    let id = UUID()
    //var title: String
    //var year: String?
    var coverImage: String?
    var localImage: Data? = nil
    var rating: Int = 0
    var albumName: String? = nil
    var artistName: String? = nil
    
    private enum CodingKeys: String, CodingKey {
        //case title
        //case year
        case coverImage = "cover_image"
        case localImage
        //case stars
        case albumName
        case artistName
        case rating
    }
    
    mutating func updateRating(val: Int) {
        rating = val
    }
}
