//
//  Album.swift
//  alBUMS
//
//  Created by Zachary Hansen Terry on 7/17/24.
//

import Foundation
import SwiftUI

struct DiscogAlbum: Identifiable, Codable {
    let id = UUID()
    var title: String
    var year: String?
    var coverImage: String?
    var localImage: Data? = nil

    private enum CodingKeys: String, CodingKey {
        case title
        case year
        case coverImage = "cover_image"
        case localImage
    }
}
