//
//  Song.swift
//  alBUMS
//
//  Created by Zachary Hansen Terry on 7/17/24.
//

import Foundation

struct Song: Identifiable {
    var id = UUID()
    var name: String
}
