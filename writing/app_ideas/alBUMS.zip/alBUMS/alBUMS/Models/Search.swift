//
//  Search.swift
//  alBUMS
//
//  Created by Zachary Hansen Terry on 7/19/24.
//

import Foundation

struct Search: Identifiable, Codable{
    var id = UUID()
    var string: String
}
