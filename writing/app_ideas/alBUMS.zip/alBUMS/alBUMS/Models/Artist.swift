//
//  Artist.swift
//  alBUMS
//
//  Created by Zachary Hansen Terry on 7/17/24.
//

import Foundation

struct Artist: Decodable {
    let name: String
}
