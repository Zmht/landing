//
//  Star.swift
//  alBUMS
//
//  Created by Zachary Hansen Terry on 7/20/24.
//

import Foundation

struct Star: Identifiable, Codable {
    var id = UUID()
    var filled: Bool
    
    private enum CodingKeys: String, CodingKey {
        case filled
    }
}
