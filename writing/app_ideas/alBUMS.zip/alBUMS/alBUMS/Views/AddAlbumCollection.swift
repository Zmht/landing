//
//  AddAlbumView.swift
//  alBUMS
//
//  Created by Zachary Hansen Terry on 7/18/24.
//

import SwiftUI

struct AddAlbumCollection: View {
    @ObservedObject var viewModel: AlbumViewModel
    @State var album: GalleryAlbum
    @Binding var isVisible: Bool
    @State private var title = ""
    @State private var artist = ""
    @State private var year = ""
    @State private var format = ""
    
    var body: some View {
        GeometryReader { geometry in
            let width = geometry.size.width - 30
            NavigationStack {
                VStack {
                    Form {
                        if let coverImage = album.coverImage, !coverImage.isEmpty {
                            AsyncImage(url: URL(string: coverImage)) { image in
                                image.resizable()
                                    .frame(width: width, height: width)
                                    .clipShape(RoundedRectangle(cornerRadius: 10))
                                    .shadow(radius: /*@START_MENU_TOKEN@*/10/*@END_MENU_TOKEN@*/)
                            } placeholder: {
                                ProgressView()
                            }
                        }
                        Section(header: Text("Title")) {
                            TextField(album.albumName ?? "", text: $title)
                        }
                        Section(header: Text("Artist")) {
                            TextField(album.artistName ?? "", text: $artist)
                        }
                        HStack {
                            Section(header: Text("Year")) {
                                //TextField(album.year ?? "", text: $year)
                                  //  .keyboardType(.numberPad)
                            }
                            Section(header: Text("Format")) {
                                TextField("Format", text: $format)
                            }
                        }
                    }
                }
                .toolbar {
                    ToolbarItemGroup(placement: .cancellationAction) {
                        Button("Cancel") {
                            isVisible = false
                        }
                    }
                    ToolbarItemGroup(placement: .confirmationAction) {
                        Button("Save") {
                            if !title.isEmpty {
                                album.albumName = title
                            }
                            if !artist.isEmpty {
                                album.artistName = artist
                            }
                            //album.format = format
                            viewModel.addAlbum(album: album, gallery: .Collection)
                            isVisible = false
                        }
                    }
                }
            }
        }
    }
}
