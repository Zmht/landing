//
//  AlbumGalleryView.swift
//  alBUMS
//
//  Created by Zachary Hansen Terry on 7/19/24.
//

import SwiftUI

struct AlbumGalleryView: View {
    @ObservedObject var viewModel: AlbumViewModel
    var galleryType: GalleryType
    
    let columns = [
        GridItem(.flexible()),
        GridItem(.flexible())
    ]
    
    var body: some View {
        GeometryReader { geometry in
            let width = geometry.size.width / 2 - 20
            ScrollView {
                LazyVGrid(columns: columns, spacing: 10) {
                    if galleryType == .Collection {
                        ForEach($viewModel.collectionAlbums) { $album in
                            GalleryCard(viewModel: viewModel, album: $album, galleryType: .Collection, width: width)
                        }
                    } else {
                        ForEach($viewModel.wishlistAlbums) { $album in
                            GalleryCard(viewModel: viewModel, album: $album, galleryType: .Wishlist, width: width)
                        }
                    }
                }
            }
        }
    }
}

        
        
        /*switch galleryType {
        case .Collection:
            GeometryReader { geometry in
                let width = geometry.size.width / 2 - 20
                ScrollView {
                    LazyVGrid(columns: columns, spacing: 10) {
                        ForEach(viewModel.collectionAlbums) { album in
                            if let imageData = album.localImage, let uiImage = UIImage(data: imageData) {
                                Image(uiImage: uiImage)
                                    .resizable()
                                    .frame(width: width, height: width)
                                    .clipShape(RoundedRectangle(cornerRadius: /*@START_MENU_TOKEN@*/25.0/*@END_MENU_TOKEN@*/))
                            } else {
                                //let _ = print(album.localImage)
                                RoundedRectangle(cornerRadius: /*@START_MENU_TOKEN@*/25.0/*@END_MENU_TOKEN@*/)
                                    .frame(width: width, height: width)
                                    .foregroundStyle(.gray)
                                    .overlay {
                                        VStack {
                                            Text(Utilities.afterFirstHyphen(string: album.title)).font(.headline)
                                            Text(Utilities.dropAfterHyphen(string: album.title)).font(.subheadline)
                                        }
                                    }
                            }
                        }
                    }
                    .onAppear{viewModel.fetchAlbums(gallery: galleryType)}
                    .padding()
                }
            }
        case .Wishlist:
            GeometryReader { geometry in
                let width = geometry.size.width / 2 - 20
                ScrollView {
                    LazyVGrid(columns: columns, spacing: 10) {
                        ForEach(viewModel.wishlistAlbums) { album in
                            GalleryCard(album: album, width: width)
                        }
                    }
                    .onAppear{viewModel.fetchAlbums(gallery: galleryType)}
                    .padding()
                }
            }
        }*/
