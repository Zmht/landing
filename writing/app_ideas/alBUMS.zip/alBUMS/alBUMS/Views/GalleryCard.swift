//
//  GalleryCard.swift
//  alBUMS
//
//  Created by Zachary Hansen Terry on 7/19/24.
//

import SwiftUI

private let radius = 25.0

struct GalleryCard: View {
    @ObservedObject var viewModel: AlbumViewModel
    @Binding var album: GalleryAlbum
    var galleryType: GalleryType
    var width: CGFloat
    @State var isFlipped = false
    
    
    var body: some View {
        ZStack {
            if isFlipped {
                backView
            } else {
                frontView
            }
        }
        .frame(width: width, height: width)
        .rotation3DEffect(.degrees(isFlipped ? 180 : 0), axis: (x: 0.0, y: 1.0, z: 0.0))
        .onTapGesture {
            withAnimation {
                isFlipped.toggle()
            }
        }
        
    }
    
    private var frontView: some View {
        Group {
            if let imageData = album.localImage, let uiImage = UIImage(data: imageData) {
                Image(uiImage: uiImage)
                    .resizable()
                    .frame(width: width, height: width)
                    .clipShape(RoundedRectangle(cornerRadius: radius))
            } else {
                //let _ = print(album.localImage)
                RoundedRectangle(cornerRadius: radius)
                    .frame(width: width, height: width)
                    .foregroundStyle(Color(red: 105 / 255, green: 20 / 255, blue: 14 / 255))
            }
        }
    }
    
    private var backView: some View {
        Group {
            RoundedRectangle(cornerRadius: radius)
                .foregroundStyle(Color(red: 242 / 255, green: 243 / 255, blue: 174 / 255))
                .overlay {
                    VStack {
                        Text(album.albumName ?? "Unknown").font(.headline).padding(.top)
                        Text(album.artistName ?? "Unknown").font(.subheadline)
                        //Spacer()
                        RatingView(viewModel: viewModel, galleryType: galleryType, album: $album)
                            .padding()
                        //let _ = print("Rating: \(album.rating)")
                        //}
                    }.rotation3DEffect(.degrees(180), axis: (x: 0.0, y: 1.0, z: 0.0))
                }
        }
    }
}


    

