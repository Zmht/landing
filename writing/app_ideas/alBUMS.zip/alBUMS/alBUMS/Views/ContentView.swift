//
//  ContentView.swift
//  alBUMS
//
//  Created by Zachary Hansen Terry on 7/17/24.
//

import SwiftUI

struct ContentView: View {
    @StateObject var albumViewModel = AlbumViewModel()
    @StateObject var searchViewModel = SearchViewModel()
    var body: some View {
        TabView {
            WishlistView(viewModel: albumViewModel)
                .tabItem {
                    Image(systemName: "gift")
                    Text("Wishlist")
                    }
            CollectionView(viewModel: albumViewModel)
                .tabItem {
                    Image(systemName: "music.note.house")
                    Text("Collection")
                }
            DiscoverView(searchViewModel: searchViewModel, albumViewModel: albumViewModel)
                .tabItem {
                    Image(systemName: "magnifyingglass")
                    Text("Discover")
                }
            ProfileView()
                .tabItem {
                    Image(systemName: "person.crop.circle")
                    Text("Profile")
                }
        }
    }
}

#Preview {
    ContentView()
}
