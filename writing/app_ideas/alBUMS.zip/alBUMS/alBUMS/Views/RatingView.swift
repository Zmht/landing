//
//  RatingView.swift
//  alBUMS
//
//  Created by Zachary Hansen Terry on 7/20/24.
//

import SwiftUI

struct RatingView: View {
    @ObservedObject var viewModel: AlbumViewModel
    var galleryType: GalleryType
    @Binding var album: GalleryAlbum
    
    var label = ""
    var maximumRating = 5
    
    var offImage: Image?
    var onImage = Image(systemName: "star.fill")
    
    var offColor = Color.gray
    var onColor = Color.yellow
    
    func image(for number: Int) -> Image {
        if number > album.rating {
            offImage ?? onImage
        } else {
            onImage
        }
    }
    
    var body: some View {
        HStack {
            if label.isEmpty == false {
                Text(label)
            }
            ForEach(1..<maximumRating+1, id: \.self) { number in
                Button {
                    album.rating = number
                    viewModel.saveAlbums(gallery: galleryType)
                } label: {
                    image(for: number)
                        .foregroundStyle(number > album.rating ? offColor : onColor)
                }
            }
        }
    }
}
