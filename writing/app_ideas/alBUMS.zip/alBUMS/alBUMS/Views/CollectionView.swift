//
//  Collection.swift
//  alBUMS
//
//  Created by Zachary Hansen Terry on 7/17/24.
//

import SwiftUI

struct CollectionView: View {
    @ObservedObject var viewModel: AlbumViewModel
    
    var body: some View {
        AlbumGalleryView(viewModel: viewModel, galleryType: .Collection).onAppear{viewModel.fetchAlbums(gallery: .Collection)}
    }
}
