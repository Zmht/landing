//
//  WishlistView.swift
//  alBUMS
//
//  Created by Zachary Hansen Terry on 7/17/24.
//

import SwiftUI
import Foundation
import Combine

struct WishlistView: View {
    @ObservedObject var viewModel: AlbumViewModel
    var body: some View {
        AlbumGalleryView(viewModel: viewModel, galleryType: .Wishlist).onAppear{viewModel.fetchAlbums(gallery: .Wishlist)}
    }
}
