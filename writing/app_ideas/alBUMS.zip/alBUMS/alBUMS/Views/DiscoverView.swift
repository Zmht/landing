//
//  DiscoverView.swift
//  alBUMS
//
//  Created by Zachary Hansen Terry on 7/17/24.
//

import SwiftUI

struct DiscoverView: View {
    @ObservedObject var searchViewModel: SearchViewModel
    @ObservedObject var albumViewModel: AlbumViewModel
    @State private var isPresentingAddAlbumView = false
    @State private var selectedAlbum: iTunesAlbum? = nil
    
    let columns = [
        GridItem(.flexible()),
        GridItem(.flexible()),
        GridItem(.flexible())
    ]

    var body: some View {
        GeometryReader { geometry in
            let width = geometry.size.width / 4
            VStack {
                TextField("Album", text: $searchViewModel.query)
                    .textFieldStyle(.roundedBorder)
                    .padding(.horizontal)
                    .padding(.top)
                    .onSubmit {
                        searchViewModel.hasSubmitted = true
                        searchViewModel.addSearchHistory(search: searchViewModel.query)
                    }
                /*List(searchViewModel.searchHistory) {history in
                    Text(history.string)
                }.*/
                List(searchViewModel.iTunesResults) { result in
                    ResultCardView(result: result, width: width, viewModel: searchViewModel)
                        .swipeActions(edge: .trailing) {
                            Button(action: {
                                selectedAlbum = result
                                isPresentingAddAlbumView = true
                            }, label: {
                                Image(systemName: "plus")
                                Text("Collection")
                            })
                            .tint(.green)
                        }
                        .swipeActions(edge: .leading) {
                            Button(action: {
                                albumViewModel.addAlbum(album: albumViewModel.iTunesToGalleryAlbum(album: result), gallery: .Wishlist)
                            }, label: {
                                Image(systemName: "gift")
                                Text("Wishlist")
                            })
                            .tint(.orange)
                        }
                }
            }
            .sheet(isPresented: Binding(get: {isPresentingAddAlbumView && selectedAlbum != nil},
                                        set: {newValue in
                                                if !newValue {
                                                    isPresentingAddAlbumView = false
                                                    selectedAlbum = nil
                                                }
                                            }
                                       )) {
                if let albumToAdd = selectedAlbum {
                    AddAlbumCollection(viewModel: albumViewModel, album: albumViewModel.iTunesToGalleryAlbum(album: albumToAdd), isVisible: $isPresentingAddAlbumView)
                } else {
                    Text("Nah")
                }
            }
        }
    }
}
