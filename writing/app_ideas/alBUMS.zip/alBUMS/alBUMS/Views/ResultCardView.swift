//
//  AlbumDetailView.swift
//  alBUMS
//
//  Created by Zachary Hansen Terry on 7/18/24.
//

import SwiftUI

struct ResultCardView: View {
    var result: iTunesAlbum
    var width: Double
    @ObservedObject var viewModel: SearchViewModel
    
    var body: some View {
        HStack(alignment: .top) {
            if let artworkURL = result.artworkUrl100, !artworkURL.isEmpty {
                AsyncImage(url: URL(string: artworkURL)) { image in
                    image.resizable()
                    .frame(width: 60, height: 60)
                    .clipShape(RoundedRectangle(cornerSize: CGSize(width: 10, height: 10)))
                    .shadow(radius: /*@START_MENU_TOKEN@*/10/*@END_MENU_TOKEN@*/)
                } placeholder: {
                    ProgressView()
                }
            } else {
                let _ = print("No Image Load")
            }
            VStack(alignment: .leading) {
                Text(result.collectionName)
                    .font(.headline)
                Text(result.artistName)
                    .font(.subheadline)
//                Text(result.year ?? "")
//                    .font(.subheadline)
            } .padding(.leading, 8)
        }
        .padding(.vertical, 8)
        
        //.listRowInsets(EdgeInsets())
    }
}
