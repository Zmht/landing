//
//  ProfileView.swift
//  alBUMS
//
//  Created by Zachary Hansen Terry on 7/17/24.
//

import SwiftUI

struct ProfileView: View {
    var body: some View {
        Text("Profile View Text")
    }
}
