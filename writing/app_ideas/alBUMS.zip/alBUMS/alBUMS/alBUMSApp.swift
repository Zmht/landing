//
//  alBUMSApp.swift
//  alBUMS
//
//  Created by Zachary Hansen Terry on 7/17/24.
//

import SwiftUI

@main
    struct alBUMSApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
