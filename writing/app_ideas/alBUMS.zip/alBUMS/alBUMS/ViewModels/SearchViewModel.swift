//
//  SearchViewModel.swift
//  alBUMS
//
//  Created by Zachary Hansen Terry on 7/17/24.
//

import Foundation
import Combine

class SearchViewModel: ObservableObject {
    @Published var discogResults: [DiscogAlbum] = []
    @Published var iTunesResults: [iTunesAlbum] = []
    @Published var query: String = ""
    @Published var artist: String = ""
    @Published var hasSubmitted: Bool = false
    @Published var searchHistory: [Search] = []
    private var cancellable: AnyCancellable?
    
    private let apiKey = "LcoOfoFKulfsLPrcpoMj"
    private let apiSecret = "BbODqJgfFJehnqqPVpRujJiDvJbpGiCr"
    private let discogsBaseURL = URL(string: "https://api.discogs.com")!
    private let itunesBaseURL = URL(string: "https://itunes.apple.com")!
    
    private let historyKey = "search_history"
    
    init() {
        //fetchSearchHistory()
        /*cancellable = $query
            .debounce(for: .milliseconds(500), scheduler: RunLoop.main)
            .sink(receiveValue: { [weak self] query in
                self?.searchAlbumsDiscogs(query: query)
                })
        }*/
        cancellable = $query
            .debounce(for: .milliseconds(500), scheduler: RunLoop.main)
            .sink(receiveValue: { [weak self] query in
                self?.searchAlbumsITunes(query: query)
                })
        }
        
    
    func fetchSearchHistory() {
        let defaults = UserDefaults.standard
        let decoder = JSONDecoder()
        if let savedData = defaults.data(forKey: historyKey) {
            if let decodedHist = try? decoder.decode([Search].self, from: savedData) {
                searchHistory = decodedHist
            }
        }
    }
    
    func saveSearchHistory() {
        let defaults = UserDefaults.standard
        let encoder = JSONEncoder()
        if let encodedHist = try? encoder.encode(searchHistory) {
            defaults.set(encodedHist, forKey: historyKey)
        }
    }
    
    func addSearchHistory(search: String) {
        let toAdd = Search(string: search)
        searchHistory.append(toAdd)
        saveSearchHistory()
    }
    
    func searchAlbumsITunes(query: String) {
        if hasSubmitted {
            let searchEndpoint = itunesBaseURL.appendingPathComponent("/search")
            var urlComponents = URLComponents(url: searchEndpoint, resolvingAgainstBaseURL: true)!
            urlComponents.queryItems = [
                URLQueryItem(name: "term", value: query),
                URLQueryItem(name: "country", value: "us"),
                URLQueryItem(name: "media", value: "music"),
                URLQueryItem(name: "entity", value: "album"),
                URLQueryItem(name: "limit", value: "10")
            ]
            guard let url = urlComponents.url else {return}
            
            let task = URLSession.shared.dataTask(with: url) {data, response, error in
                if let error = error {
                    print(String(describing: error))
                    return
                }
                
                guard let httpResponse = response as? HTTPURLResponse,
                      (200...299).contains(httpResponse.statusCode) else {
                    print("Error: Invalid HTTP response")
                    return
                }
                
                if let data = data {
                    do {
                        let decoder = JSONDecoder()
                        let searchResult = try decoder.decode(iTunesSearchResult.self, from: data)
                        
                        var albums = searchResult.results
                        for index in albums.indices {
                            albums[index].updateArtworkurl800()
                        }
                        
                        DispatchQueue.main.async {
                            self.iTunesResults = albums
                        }
                        
                    } catch {
                        print(String(describing: error))
                    }
                    print(data)
                } else {
                    print("Error: Invalid JSON data")
                }
            }
            task.resume()
        }
    }
    
    func searchAlbumsDiscogs(query: String) {
        if hasSubmitted {
            let searchEndpoint = discogsBaseURL.appendingPathComponent("/database/search")
            var urlComponents = URLComponents(url: searchEndpoint, resolvingAgainstBaseURL: true)!
            urlComponents.queryItems = [
                URLQueryItem(name: "q", value: query),
                URLQueryItem(name: "key", value: apiKey),
                URLQueryItem(name: "secret", value: apiSecret),
                URLQueryItem(name: "per_page", value: "10"),
                URLQueryItem(name: "page", value: "1"),
                URLQueryItem(name: "country", value: "US"),
                URLQueryItem(name: "artist", value: artist),
                URLQueryItem(name: "type", value: "release"),
                URLQueryItem(name: "format", value: "album")
            ]
            guard let url = urlComponents.url else { return }
            
            let task = URLSession.shared.dataTask(with: url) { (data, response, error) in
                if let error = error {
                    print("Error fetching data: \(error.localizedDescription)")
                    return
                }
                
                guard let httpResponse = response as? HTTPURLResponse,
                      (200...299).contains(httpResponse.statusCode) else {
                    print("Error: Invalid HTTP response")
                    return
                }
                
                if let data = data {
                    do {
                        let decoder = JSONDecoder()
                        let searchResult = try decoder.decode(DiscogSearchResult.self, from: data)
                        
                        DispatchQueue.main.async {
                            self.discogResults = searchResult.results
                        }
                        
                    } catch {
                        print(String(describing: error))
                    }
                    print(data)
                } else {
                    print("Error: Invalid JSON data")
                }
            }
            task.resume()
        }
    }
}
