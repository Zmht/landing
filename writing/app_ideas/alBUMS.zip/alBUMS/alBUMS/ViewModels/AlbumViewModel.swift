//
//  AlbumViewModel.swift
//  alBUMS
//
//  Created by Zachary Hansen Terry on 7/17/24.
//

import Combine
import Foundation
import SwiftUI

class AlbumViewModel: ObservableObject {
    //@Binding var ratingVal: Int
    @Published var collectionAlbums: [GalleryAlbum] = []
    @Published var wishlistAlbums: [GalleryAlbum] = []
   
    
    let collectionKey = "collection"
    let wishlistKey = "wishlist"
    
    init(ratingValue: Int = 0) {
        //self.ratingVal = ratingValue
        fetchAlbums(gallery: .Collection)
        fetchAlbums(gallery: .Wishlist)
    }
    
    func fetchAlbums(gallery: GalleryType) {
        switch gallery {
        case .Collection:
            let defaults = UserDefaults.standard
            let decoder = JSONDecoder()
            if let savedData = defaults.data(forKey: collectionKey) {
                if let decodedAlbums = try? decoder.decode([GalleryAlbum].self, from: savedData) {
                    collectionAlbums = decodedAlbums
                }
            }
            
        case .Wishlist:
            let defaults = UserDefaults.standard
            let decoder = JSONDecoder()
            if let savedData = defaults.data(forKey: wishlistKey) {
                if let decodedAlbums = try? decoder.decode([GalleryAlbum].self, from: savedData) {
                    wishlistAlbums = decodedAlbums
                }
            }
        }
    }
        
        
    func saveAlbums(gallery: GalleryType) {
        switch gallery {
        case .Collection:
            let defaults = UserDefaults.standard
            let encoder = JSONEncoder()
            if let encodedAlbums = try? encoder.encode(collectionAlbums) {
                defaults.set(encodedAlbums, forKey: collectionKey)
            }
            
        case .Wishlist:
            let defaults = UserDefaults.standard
            let encoder = JSONEncoder()
            if let encodedAlbums = try? encoder.encode(wishlistAlbums) {
                defaults.set(encodedAlbums, forKey: wishlistKey)
            }
        }
    }
        
        func addAlbum(album: GalleryAlbum, gallery: GalleryType) {
            switch gallery {
            case .Collection:
                var albumToAdd = album
                downloadImage(urlString: album.coverImage ?? "") { data in
                    if let data = data  {
                        albumToAdd.localImage = data
                        DispatchQueue.main.async {
                            self.collectionAlbums.append(albumToAdd)
                            self.saveAlbums(gallery: gallery)
                        }
                    } else {
                        print("Error Happened!")
                    }
                }
                
            case .Wishlist:
                var albumToAdd = album
                downloadImage(urlString: album.coverImage ?? "") { data in
                    if let data = data  {
                        albumToAdd.localImage = data
                        DispatchQueue.main.async {
                            self.wishlistAlbums.append(albumToAdd)
                            self.saveAlbums(gallery: gallery)
                        }
                    } else {
                        print("Error Happened!")
                    }
                }
            }
        }
    
    func discogToGalleryAlbum(album: DiscogAlbum) -> GalleryAlbum {
        var galleryAlbum = GalleryAlbum(rating: 0)
        galleryAlbum.albumName = Utilities.afterFirstHyphen(string: album.title)
        galleryAlbum.artistName = Utilities.dropAfterHyphen(string: album.title)
        galleryAlbum.coverImage = album.coverImage
        galleryAlbum.localImage = album.localImage
        return galleryAlbum
    }
    
    func iTunesToGalleryAlbum(album: iTunesAlbum) -> GalleryAlbum {
        var galleryAlbum = GalleryAlbum(rating: 0)
        galleryAlbum.albumName = album.collectionName
        galleryAlbum.artistName = album.artistName
        if let url = album.artworkUrl800 {
            galleryAlbum.coverImage = url
        } else {
            galleryAlbum.coverImage = album.artworkUrl100
        }
        galleryAlbum.localImage = album.localImage
        return galleryAlbum
    }
        
        func downloadImage(urlString: String, completion: @escaping (Data?) -> Void) {
            guard let url = URL(string: urlString) else {
                completion(nil)
                return
            }
            URLSession.shared.dataTask(with: url) {data, response, error in
                if let error = error {
                    completion(nil)
                    print(String(describing: error))
                } else {
                    completion(data)
                }
            }.resume()
        }
    }



