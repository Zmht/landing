//
//  TechHelperApp.swift
//  TechHelper
//
//  Created by Zachary Hansen Terry on 7/25/24.
//

import SwiftUI

@main
struct TechHelperApp: App {
    @UIApplicationDelegateAdaptor(AppDelegate.self) var delegate
    @StateObject private var userAuth = UserAuth()
    
    var body: some Scene {
        WindowGroup {
            ContentView()
                .environmentObject(userAuth)
        }
    }
}
