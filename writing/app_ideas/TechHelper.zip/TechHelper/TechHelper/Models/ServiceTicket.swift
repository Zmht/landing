//
//  ServiceTicket.swift
//  TechHelpNow
//
//  Created by Zachary Hansen Terry on 7/24/24.
//

import Foundation

struct ServiceTicket: Identifiable {
    var id = UUID()
    var description: String
    var detailedDescription: String?
    var customer: User
    var price: Double
    var creationDate: Date
    var tags: [String]?
}
