//
//  User.swift
//  TechHelpNow
//
//  Created by Zachary Hansen Terry on 7/24/24.
//

import Foundation

struct User: Identifiable {
    var id = UUID()
    var firstName: String
    var lastName: String
    var phoneNumber: Int
}
