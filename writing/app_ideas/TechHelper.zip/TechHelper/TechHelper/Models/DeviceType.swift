//
//  DeviceType.swift
//  TechHelpNow
//
//  Created by Zachary Hansen Terry on 7/24/24.
//

import Foundation

enum DeviceType {
    case iphone, android, other
}
