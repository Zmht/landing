//
//  UserAuth.swift
//  TechHelper
//
//  Created by Zachary Hansen Terry on 7/25/24.
//

import Foundation
import Firebase

class UserAuth: ObservableObject {
    @Published var isLoggedIn: Bool = false
    
    init() {
        Auth.auth().addStateDidChangeListener { auth, user in
            self.isLoggedIn = user != nil
        }
    }
    
    func signOut() {
        try? Auth.auth().signOut()
    }
}
