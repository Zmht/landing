//
//  ServiceTicketViewModel.swift
//  TechHelpNow
//
//  Created by Zachary Hansen Terry on 7/24/24.
//

import Foundation

class ServiceTicketViewModel: ObservableObject {
    @Published var tickets: [ServiceTicket]
    
    let exampleUser = User(firstName: "John", lastName: "Doe", phoneNumber: 0)
    
    
    init() {
        self.tickets = [
            ServiceTicket(description: "Laptop won't start", detailedDescription: "The laptop doesn't power on at all. No lights or sounds.", customer: exampleUser, price: 10.99, creationDate: Date.now, tags: ["Hardware", "Laptop"]),
            ServiceTicket(description: "Internet connection issues", detailedDescription: "The Wi-Fi keeps dropping and doesn't connect reliably.", customer: exampleUser, price: 10.99, creationDate: Date.now, tags: ["Network", "Internet"]),
            ServiceTicket(description: "Printer not responding", detailedDescription: "The printer is not responding to any print jobs and displays an error message.", customer: exampleUser, price: 10.99, creationDate: Date.now, tags: ["Peripheral", "Printer"]),
            ServiceTicket(description: "Software installation failed", detailedDescription: "An error occurs during the installation of a critical software update.", customer: exampleUser, price: 10.99, creationDate: Date.now, tags: ["Software", "Installation"]),
            ServiceTicket(description: "Slow computer performance", detailedDescription: "The computer is unusually slow and takes a long time to open applications.", customer: exampleUser, price: 10.99, creationDate: Date.now, tags: ["Performance", "Computer"]),
            ServiceTicket(description: "Forgot password", detailedDescription: "User has forgotten their password and needs a reset.", customer: exampleUser, price: 10.99, creationDate: Date.now, tags: ["Account", "Password"]),
            ServiceTicket(description: "Blue screen of death", detailedDescription: "The computer shows a blue screen with an error message and restarts.", customer: exampleUser, price: 10.99, creationDate: Date.now, tags: ["Error", "Crash"]),
            ServiceTicket(description: "Overheating laptop", detailedDescription: "The laptop becomes excessively hot during use and shuts down.", customer: exampleUser, price: 10.99, creationDate: Date.now, tags: ["Hardware", "Overheating"]),
            ServiceTicket(description: "Email not syncing", detailedDescription: "Email client is not syncing with the server and missing recent emails.", customer: exampleUser, price: 10.99, creationDate: Date.now, tags: ["Email", "Sync"]),
            ServiceTicket(description: "Graphics card issues", detailedDescription: "The graphics card is not functioning correctly, causing display artifacts.", customer: exampleUser, price: 10.99, creationDate: Date.now, tags: ["Hardware", "Graphics"]),
            ServiceTicket(description: "Virus infection", detailedDescription: "The computer is infected with a virus and is showing unusual behavior.", customer: exampleUser, price: 10.99, creationDate: Date.now, tags: ["Security", "Virus"]),
            ServiceTicket(description: "Application crashes on startup", detailedDescription: "A specific application crashes every time it is launched.", customer: exampleUser, price: 10.99, creationDate: Date.now, tags: ["Software", "Crash"]),
            ServiceTicket(description: "Hard drive failure", detailedDescription: "The hard drive is making unusual noises and failing to read/write data.", customer: exampleUser, price: 10.99, creationDate: Date.now, tags: ["Hardware", "Hard Drive"]),
            ServiceTicket(description: "Password manager issues", detailedDescription: "The password manager application is not filling in credentials automatically.", customer: exampleUser, price: 10.99, creationDate: Date.now, tags: ["Software", "Password Manager"]),
            ServiceTicket(description: "Bluetooth device not pairing", detailedDescription: "A Bluetooth device will not pair with the computer or mobile device.", customer: exampleUser, price: 10.99, creationDate: Date.now, tags: ["Peripheral", "Bluetooth"]),
            ServiceTicket(description: "Software update stuck", detailedDescription: "A software update is stuck at a certain percentage and won't progress.", customer: exampleUser, price: 10.99, creationDate: Date.now, tags: ["Software", "Update"]),
            ServiceTicket(description: "Data backup failure", detailedDescription: "The scheduled data backup has failed and no backup was created.", customer: exampleUser, price: 10.99, creationDate: Date.now, tags: ["Backup", "Data"]),
            ServiceTicket(description: "Broken laptop screen", detailedDescription: "The laptop screen is cracked or not displaying correctly.", customer: exampleUser, price: 10.99, creationDate: Date.now, tags: ["Hardware", "Screen"]),
            ServiceTicket(description: "External hard drive not recognized", detailedDescription: "The external hard drive is not being recognized by the computer.", customer: exampleUser, price: 10.99, creationDate: Date.now, tags: ["Hardware", "External Drive"]),
            ServiceTicket(description: "Website not loading", detailedDescription: "A specific website is not loading or returning errors.", customer: exampleUser, price: 10.99, creationDate: Date.now, tags: ["Web", "Internet"]),
            ServiceTicket(description: "Operating system reinstall", detailedDescription: "The operating system needs to be reinstalled due to corruption or errors.", customer: exampleUser, price: 10.99, creationDate: Date.now, tags: ["Software", "Reinstall"]),
            ServiceTicket(description: "Smartphone battery draining quickly", detailedDescription: "The smartphone battery is draining unusually fast and needs to be checked.", customer: exampleUser, price: 10.99, creationDate: Date.now, tags: ["Hardware", "Battery"]),
            ServiceTicket(description: "Network printer setup", detailedDescription: "Setting up a new network printer and configuring it for multiple users.", customer: exampleUser, price: 10.99, creationDate: Date.now, tags: ["Printer", "Network"]),
            ServiceTicket(description: "Keyboard keys not working", detailedDescription: "Certain keys on the keyboard are not responding or are sticky.", customer: exampleUser, price: 10.99, creationDate: Date.now, tags: ["Peripheral", "Keyboard"]),
            ServiceTicket(description: "Email account configuration", detailedDescription: "Configuring a new email account in the email client.", customer: exampleUser, price: 10.99, creationDate: Date.now, tags: ["Email", "Configuration"]),
            ServiceTicket(description: "Error 404 on website", detailedDescription: "A website is showing a 404 error page when accessed.", customer: exampleUser, price: 10.99, creationDate: Date.now, tags: ["Web", "Error"]),
            ServiceTicket(description: "USB port not working", detailedDescription: "A USB port is not recognizing devices or not functioning.", customer: exampleUser, price: 10.99, creationDate: Date.now, tags: ["Hardware", "USB"]),
            ServiceTicket(description: "Application license activation issues", detailedDescription: "Problems activating the license for a specific application.", customer: exampleUser, price: 10.99, creationDate: Date.now, tags: ["Software", "License"]),
            ServiceTicket(description: "Wi-Fi signal strength weak", detailedDescription: "The Wi-Fi signal is weak or intermittent in certain areas.", customer: exampleUser, price: 10.99, creationDate: Date.now, tags: ["Network", "Wi-Fi"]),
            ServiceTicket(description: "System performance tuning", detailedDescription: "Optimizing system settings to improve overall performance.", customer: exampleUser, price: 10.99, creationDate: Date.now, tags: ["Performance", "System"]),
            ServiceTicket(description: "Broken charging port", detailedDescription: "The charging port on a laptop or smartphone is damaged and not charging.", customer: exampleUser, price: 10.99, creationDate: Date.now, tags: ["Hardware", "Charging Port"]),
            ServiceTicket(description: "Malware removal", detailedDescription: "Removing malware or adware from the computer.", customer: exampleUser, price: 10.99, creationDate: Date.now, tags: ["Security", "Malware"]),
            ServiceTicket(description: "Audio issues", detailedDescription: "No sound or distorted sound coming from the speakers or headphones.", customer: exampleUser, price: 10.99, creationDate: Date.now, tags: ["Hardware", "Audio"]),
            ServiceTicket(description: "Laptop keyboard backlight not working", detailedDescription: "The backlight on the laptop keyboard is not functioning.", customer: exampleUser, price: 10.99, creationDate: Date.now, tags: ["Hardware", "Keyboard"]),
            ServiceTicket(description: "Tablet screen unresponsive", detailedDescription: "The touch screen on the tablet is not responding to touch input.", customer: exampleUser, price: 10.99, creationDate: Date.now, tags: ["Hardware", "Tablet"]),
            ServiceTicket(description: "Cloud storage sync issues", detailedDescription: "Files are not syncing correctly with cloud storage services.", customer: exampleUser, price: 10.99, creationDate: Date.now, tags: ["Cloud", "Sync"])
        ]
    }
    
    func addTicket(description: String, customer: User, price: Double) {
        let newTicket = ServiceTicket(description: description, customer: customer, price: price, creationDate: Date.now)
        tickets.append(newTicket)
    }
}
