//
//  TagView.swift
//  TechHelpNow
//
//  Created by Zachary Hansen Terry on 7/24/24.
//

import SwiftUI

struct TagView: View {
    var tag: String
    var body: some View {
        Text(tag)
            .font(.system(size: 14))
            .padding(.horizontal, 10)
            .padding(.vertical, 5)
            .background(
                RoundedRectangle(cornerRadius: 10)
                    .foregroundStyle(.yellow)
            )
            .foregroundStyle(.white)
            .fixedSize(horizontal: /*@START_MENU_TOKEN@*/true/*@END_MENU_TOKEN@*/, vertical: false)
        
//        RoundedRectangle(cornerRadius: 10)
//            .foregroundStyle(.orange)
//            //.frame(width: 50, height: 10)
//            .overlay {
//                Text(tag)
//                    .foregroundStyle(.white)
//            }
    }
}

