//
//  ServiceTicketDetailView.swift
//  TechHelpNow
//
//  Created by Zachary Hansen Terry on 7/24/24.
//

import SwiftUI

struct ServiceTicketDetailView: View {
    var ticket: ServiceTicket
    
    var body: some View {
        NavigationStack {
            VStack(alignment: .leading) {
                Text(ticket.description)
                    .font(.largeTitle)
                    .padding(.horizontal)
                if let tags = ticket.tags {
                    HStack {
                        ForEach(tags, id: \.self) {tag in
                            TagView(tag: tag)
                        }
                    }
                    .padding(.horizontal)
                    .padding(.bottom)
                }
                Text("$\(String(format: "%.2f", ticket.price))")
                    .font(.headline)
                    .foregroundStyle(.blue)
                    .padding(.horizontal)
                if let detailDesc = ticket.detailedDescription {
                    Text("Detailed Description:")
                        .font(.headline)
                        .padding(.horizontal)
                        .padding(.top)
                        .padding(.bottom, 8)
                    Text(detailDesc)
                        .padding(.horizontal)
                }
                Spacer()
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .topLeading)

            Button(action: {
                print("Accepted")
            }){
                Text("Accept Job")
                    .padding()
                    .background(.blue)
                    .foregroundStyle(.white)
                    .clipShape(Capsule())
            }
            .padding()
        }
        .navigationBarTitleDisplayMode(.inline)
    }
}

#Preview {
    ServiceTicketDetailView(ticket: ServiceTicket(description: "App Store Login", detailedDescription: "Whenever I try to sign in to the App Store, I get an error message saying, “Unable to sign in. Please check your Apple ID and password and try again.” I’ve made sure my credentials are correct, but I keep getting the same message. Sometimes, I see a different error that says, “The App Store is temporarily unavailable. Please try again later,” which makes me think it might be a connectivity issue or something else.", customer: User(firstName: "John", lastName: "Doe", phoneNumber: 0), price: 12.99, creationDate: Date.now, tags: ["iOS 17.5", "app store"]))
}
