//
//  ContentView.swift
//  TechHelpNow
//
//  Created by Zachary Hansen Terry on 7/24/24.
//

import SwiftUI

struct ContentView: View {
    @EnvironmentObject var userAuth: UserAuth
    
    var body: some View {
        if(userAuth.isLoggedIn) {
            TabView {
                GetHelpView()
                    .tabItem {
                        Image(systemName: "info.circle")
                        Text("Get Help")
                    }
                HelperView()
                    .tabItem {
                        Image(systemName: "lifepreserver")
                        Text("Help")
                    }
                ProfileView()
                    .tabItem {
                        Image(systemName: "person.crop.circle")
                        Text("Your Profile")
                    }
            }
        } else {
            RegistrationView()
        }
        
    }
}

#Preview {
    ContentView()
}
