//
//  RegistrationView.swift
//  TechHelper
//
//  Created by Zachary Hansen Terry on 7/25/24.
//

import SwiftUI
import Firebase

struct RegistrationView: View {
    @State private var email: String = ""
    @State private var password: String = ""
    @State private var errorMessage: String?

    var body: some View {
        VStack {
            TextField("Email", text: $email)
                .textFieldStyle(RoundedBorderTextFieldStyle())
                .padding()

            SecureField("Password", text: $password)
                .textFieldStyle(RoundedBorderTextFieldStyle())
                .padding()

            if let errorMessage = errorMessage {
                Text(errorMessage)
                    .foregroundColor(.red)
            }

            Button(action: register) {
                Text("Register")
                    .padding()
                    .background(Color.blue)
                    .foregroundColor(.white)
                    .cornerRadius(8)
            }
            .padding()
        }
        .padding()
    }

    private func register() {
        Auth.auth().createUser(withEmail: email, password: password) { authResult, error in
            if let error = error {
                print("Registration error: \(error.localizedDescription)")
                print("Error details: \(error)")
                errorMessage = error.localizedDescription
            } else {
                //authResult.
                // Handle successful registration
            }
        }
    }
}

#Preview {
    RegistrationView()
}
