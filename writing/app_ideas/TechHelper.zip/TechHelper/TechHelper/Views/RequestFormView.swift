//
//  RequestFormView.swift
//  TechHelpNow
//
//  Created by Zachary Hansen Terry on 7/24/24.
//

import SwiftUI

struct RequestFormView: View {
    @ObservedObject var viewModel = ServiceTicketViewModel()
    
    @State private var title: String = ""
    @State private var price: String = ""
    @State private var detailedDescription: String = ""
    @State private var deviceType: DeviceType = .iphone
    @State private var iosVersion: Int = 0
    @State private var iphoneVersion: Int = 0
    @State private var androidType: String = ""
    
    var body: some View {
        NavigationStack {
            VStack {
                Form {
                    Section("General") {
                        TextField("Title", text: $title)
                        TextField("Price", text: $price)
                            .keyboardType(.decimalPad)
                    }
                    Section("Details") {
                        TextField("Detailed Description", text: $detailedDescription, axis: .vertical)
                        Picker(selection: $deviceType) {
                            Text("iPhone").tag(DeviceType.iphone)
                            Text("Android").tag(DeviceType.android)
                            Text("Other").tag(DeviceType.other)
                        } label: {
                            Text("Device Type").foregroundStyle(.tertiary)
                        }
                        if deviceType == .iphone {
                            HStack {
                                VStack {
                                    Text("iPhone Version")
                                    Picker("", selection: $iphoneVersion) {
                                        ForEach(6..<16) { index in
                                            Text("\(index)").tag(index)
                                        }
                                    }
                                    .pickerStyle(.wheel)
                                    .frame(maxWidth: /*@START_MENU_TOKEN@*/.infinity/*@END_MENU_TOKEN@*/)
                                    .frame(height: 100)
                                }
                                VStack {
                                    Text("iOS Version")
                                    Picker("", selection: $iosVersion) {
                                        ForEach(13..<19) { index in
                                            Text("\(index)").tag(index)
                                        }
                                    }
                                    .pickerStyle(.wheel)
                                    .frame(maxWidth: .infinity)
                                    .frame(height: 100)
                                }
                            }
                        }
                        if deviceType == .android {
                            TextField("Android Type", text: $androidType)
                        }
                        
                        
                    }
                }
                Spacer()
                Group {
                    NavigationLink(destination: GetHelpView()) {
                        Text("Request For: $\(formatPrice())")
                            .padding()
                            .background(.blue)
                            .foregroundStyle(.white)
                            .clipShape(Capsule())
                    }
                    .simultaneousGesture(TapGesture().onEnded {
                        makeRequest()
                    })
                }
                .padding()
            }
        }.navigationTitle("New Request")
    }
    
    func makeRequest() {
        print("Request Made")
        let newTicket = ServiceTicket(description: title, detailedDescription: detailedDescription, customer: User(firstName: "Jane", lastName: "Doe", phoneNumber: 0), price: Double(price) ?? 0.0, creationDate: Date.now)
        viewModel.tickets.append(newTicket)
        
    }
    
    func formatPrice() -> String {
        if let num = Double(price) {
            return String(format: "%.2f", num)
        } else {
            return "0.00"
        }
    }
       
}

#Preview {
    RequestFormView()
}
