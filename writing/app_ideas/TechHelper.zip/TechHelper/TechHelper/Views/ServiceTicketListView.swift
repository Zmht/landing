//
//  ServiceTicketView.swift
//  TechHelpNow
//
//  Created by Zachary Hansen Terry on 7/24/24.
//

import SwiftUI

struct ServiceTicketListView: View {
    @ObservedObject var viewModel = ServiceTicketViewModel()
    @State var searchText: String = ""
    
    var filteredTickets: [ServiceTicket] {
        if searchText.isEmpty {
            return viewModel.tickets
        } else {
            return viewModel.tickets.filter { ticket in
                ticket.description.lowercased().contains(searchText.lowercased()) || (ticket.tags?.contains {
                    $0.lowercased().contains(searchText.lowercased())
                } ?? false)
            }
        }
    }
    
    var body: some View {
        NavigationStack {
            List(filteredTickets) { ticket in
                NavigationLink(destination: ServiceTicketDetailView(ticket: ticket)) {
                    VStack(alignment: .leading) {
                        Text(ticket.description)
                            .font(.headline)
                        Text("$\(String(format: "%.2f", ticket.price))")
                            .font(.subheadline)
                            .foregroundStyle(.blue)
                        if let tags = ticket.tags {
                            HStack {
                                ForEach(tags, id: \.self) {tag in
                                    TagView(tag: tag)//.fixedSize()
                                }
                            }
                        }
                    }
                }
            }
        }
        .searchable(text: $searchText, placement: .automatic)
    }
}

#Preview {
    ServiceTicketListView()
}
