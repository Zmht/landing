//
//  Profile View.swift
//  TechHelpNow
//
//  Created by Zachary Hansen Terry on 7/24/24.
//

import SwiftUI

struct ProfileView: View {
    var body: some View {
        Text("Profile View Text")
    }
}

#Preview {
    ProfileView()
}
