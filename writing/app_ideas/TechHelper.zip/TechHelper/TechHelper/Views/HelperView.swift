//
//  HelperView.swift
//  TechHelpNow
//
//  Created by Zachary Hansen Terry on 7/24/24.
//

import SwiftUI

struct HelperView: View {
    var body: some View {
        ServiceTicketListView()
    }
}

#Preview {
    HelperView()
}
