//
//  GetHelpView.swift
//  TechHelpNow
//
//  Created by Zachary Hansen Terry on 7/24/24.
//

import SwiftUI

struct GetHelpView: View {
    var columns = [
        GridItem(.flexible()),
        GridItem(.flexible())
    ]
    var body: some View {
        NavigationStack {
            VStack {
                HStack {
                    Text("Get Help")
                        .font(.largeTitle)
                        .fontWeight(/*@START_MENU_TOKEN@*/.bold/*@END_MENU_TOKEN@*/)
                        .padding(.leading)
                    Spacer()
                }.padding(.bottom, 30)
                NavigationLink(destination: RequestFormView()) {
                    GetHelpButtonView(icon: "plus.rectangle.fill", title: "New Request", color: .green)
                }
                HStack {//(columns: columns) {
                    NavigationLink(destination: ActiveRequestsListView()) {
                        GetHelpButtonView(icon: "exclamationmark.bubble", title: "Active Requests", color: .blue)
                    }
                    NavigationLink(destination: InboxView()) {
                        GetHelpButtonView(icon: "tray.fill", title: "Inbox", color: .orange)
                    }
                }
                
                //            List {
                //                Text("Test")
                //                Text("Test 2")
                //            }
                Spacer()
            }.padding()
        }
    }
}

struct GetHelpButtonView: View {
    var icon: String
    var title: String
    var color: Color
    
    var body: some View {
        VStack {
            Image(systemName: icon)
                .foregroundStyle(color)
                .font(.largeTitle)
                .frame(height: 35)
                .padding(.bottom, 5)
            
            Text(title)
                .font(.headline)
                //.foregroundStyle(.white)
                .padding(.top, 2)
        }
        .frame(maxWidth: /*@START_MENU_TOKEN@*/.infinity/*@END_MENU_TOKEN@*/)
        //.frame(height: 70)
        .padding()
        .background(.quinary)
        .clipShape(RoundedRectangle(cornerRadius: 15))
       // .foregroundStyle(.black)
        
    }

    
}

#Preview {
    GetHelpView()
}
